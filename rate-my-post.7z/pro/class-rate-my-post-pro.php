<?php

/**
 * PRO FUNCTIONALITY OF THE PLUGIN
 *
 * @link       http://wordpress.org/plugins/rate-my-post/
 * @since      3.2.0
 *
 * @package    Rate_My_Post
 * @subpackage Rate_My_Post/pro
 */

// Requires PRO version...
